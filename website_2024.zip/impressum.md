---
title: Impressum
layout: page
description: Impressum
---

# Publisher

Information provided pursuant to § 5 of the TMG (German Telemedia Act):

## Service provider

Holger Fürst
TGU enviConnect
TTI – Technologie-Transfer-Initiative GmbH an der Universität Stuttgart (TTI GmbH)
Nobelstrasse 15
70569 Stuttgart
Deutschland

## Contact details

Email: info@enviconnect.de
Phone: +49 123 456 789

Contact via email is preferred.

## VAT Registration

VAT Registration Number pursuant to §27a of the German Value Added Tax Act: DE 194-532-993

## Journalistic Content
Responsible for the content pursuant to § 55 para. 2 of the RStV (German Interstate Broadcasting Treaty): Holger Fürst
