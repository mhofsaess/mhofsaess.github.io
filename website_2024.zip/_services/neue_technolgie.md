---
title: "Neue Technologien"
date: 2019-05-18T12:33:46+10:00
weight: 7
---

Nutzen Sie unsere jahrzehntelange F&E-Expertise, um Ihre Probleme zu lösen. Wir arbeiten mit Ihnen zusammen, um schnell ein Projekte zu planen, das Ihren Anforderungen entspricht

![Neue Technologie](/images/illustrations/nikita-kachanovsky-bLY5JqP_Ldw-unsplash_2W1H.jpg)

# Nutzen Sie unsere jahrzehntelange F&E-Expertise, um Ihre Probleme zu lösen.

Wir arbeiten mit Ihnen zusammen, um schnell ein Projekt zu planen, das Ihren Anforderungen entspricht. Wir halten es mit agilem Projektmanagement und enger Zusammenarbeit mit Ihnen auf Kurs.

#Lidars und Drohnen als Retter in der Not

Manchmal braucht man eine zweite Meinung zu einem Problem, bevor man entscheidet wie man weiter vorgeht. Wenn man mehr über eine in Betrieb befindliche Windenergieanlage wissen will, ist das nicht immer so einfach; es braucht Zeit, meteorologische Masten aufzustellen, um die Bedingungen rund um eine Windenergieanlage zu messen.

Hier kommen die Fernerkundung mit Wind-Lidar und direkte Messungen mit Drohnen ins Spiel. Wir können Windlidargeräte für Sie betreiben und Ihnen so einen schnellen Blick auf die Windverhältnisse an Ihrem Standort ermöglichen. Sobald wir wissen, was zu erwarten ist, können wir gemeinsam mit Ihnen detailliertere Untersuchungen planen. Das spart Kosten und liefert Ihnen die richtigen Ergebnisse.

# Unser Forschungshintergrund

Vor der Gründung von enviConnect haben wir alle gemeinsam am Lehrstuhl für Windenergie an der Universität Stuttgart gearbeitet. Davor haben unsere Mitarbeiter in China, den USA, Kanada, der Schweiz, Großbritannien, Dänemark und vielen anderen Orten gearbeitet. Wir waren an der Forschung und Entwicklung in allen Bereichen beteiligt, von der Aerodynamik bis hin zu Wirbelschleppen, von Lawinen bis zur Wellenmodellierung. Wir haben kleine Projekte durchgeführt, die in wenigen Wochen konzipiert und eingerichtet wurden und innerhalb eines Monats Ergebnisse lieferten, sowie größere Projekte, deren Initiierung und Umsetzung Jahre dauerte.

Wenn Sie also ein F&E-Projekt im Bereich der erneuerbaren Energien durchführen möchten, können wir Ihnen vielleicht helfen. Verbinden, um mehr zu erfahren.

# Unser Netzwerk

Wir haben manchmal nicht Intern alle Fähigkeiten die wir brauchen um Ihre Frage zu beantworten. Aber wir sind in der Windenergiebranche und in den F&E-Gemeinschaften sehr gut vernetzt. Wir stellen das Team zusammen, das Sie brauchen, um Ihnen die beste Lösung zu bieten.