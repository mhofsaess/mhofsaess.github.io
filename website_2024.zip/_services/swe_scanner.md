---
title: "SWE Scanning Lidar 2.0"
date: 2018-11-18T12:33:46+10:00
weight: 1
---

# Manchmal muss man etwas Besonderes oder Ungewöhnliches mit Wind-Lidar machen.

![Accounting Services](/images/austin-distel-nGc5RT2HmF0-unsplash.jpg)

Hierfür brauchen Sie einen Partner, der maßgeschneiderte Wind-Lidar-Lösungen entwickelt und einsetzt.

# Ihre maßgeschneiderte Lidar-Lösung


Wir sind Experten in der Entwicklung und im Einsatz von Wind-Lidar. Wir haben bestehende Lidargeräte angepasst und mehrere von Grund auf neu entwickelt.

# Wir arbeiten mit Ihnen zusammen, um die Lidar-Lösung zu entwickeln, die Sie benötigen.

Und wir haben das Team und die Erfahrung, um maßgeschneiderte Messkampagnen zu planen, sie durchzuführen und die Ergebnisse zu liefern.
Demnächst - ein robustes Scanning-Lidar

Wir haben ein hochflexibles, individuell programmierbares Lidar entwickelt. Es ist klein, leicht und basiert auf dem [OpenLidar-Konzept](https://zenodo.org/record/3416356), so dass es auf viele ungewöhnliche Arten programmiert und eingesetzt werden kann.

Mit unserem Gerät können Sie mehr tun als je zuvor. Unser Scanner ist schnell und genau, und das Lidar wurde von Anfang an so konzipiert, dass es flexibel, aber dennoch robust und zuverlässig ist.