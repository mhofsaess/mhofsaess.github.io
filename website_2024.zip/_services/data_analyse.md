---
title: "Data Analyse"
date: 2018-12-28T15:14:39+10:00
weight: 1
---

Haben Sie Probleme mit Windpark - Unterperformance? Oder wurde eine Messkampagne durchgeführt, aber die Auswertung ist noch nicht eindeutig?

# Analyse und Auswertungen

Unkonventionelle Probleme zu lösen ist aufgrund des wissenschaftlichen Hintergrunds unser tägliches Geschäft.

![Data Analyse](/images/illustrations/thomas-galler-q5TF6n5Kjlo-unsplash-2W1H.jpg)



# Windenergieforschung

Wir sind ExpertInnen in der Planung, Durchführung und Auswertung von Messkampagnen mit Lidar- und In-Situ-Sensoren. Des Weiteren besitzen wir ein tiefes Verständnis für die Anlagentechnik.

Wir verfügen über ein umfangreiches Softwarepaket zur Datenanalyse und -auswertung, sodass Ergebnisse schnell und übersichtlich aufbereitet zur Verfügung gestellt werden können.

Sind Sie mit Ihrem Latein am Ende? Kommen Sie zu uns!