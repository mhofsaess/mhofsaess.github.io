---
title: News
layout: page
description: News
---


# Januar 2024

Wir haben die Apps- und Digitalisierungsgruppe von enviConnect ausgegliedert und operieren nun als neue, separate Unternehmung unter dem Namen [<img src="/images/logo/enerlace.png" alt="image" width="200" height="auto">](https://www.enerlace.de/). 

Wir wünschen Andy, Ines und John alles Gute. 





# 2023

Wir haben erfolgreich mit der [<img src="/images/logo/ost_logo.jpg" alt="image" width="200" height="auto">](https://www.ost.ch/de/forschung-und-dienstleistungen/technik/erneuerbare-energien-und-umwelttechnik/iet-institut-fuer-energietechnik/fachbereiche-mitarbeitende)  und  [<img src="/images/logo/rtdtai.webp" alt="image" width="200" height="auto">](https://www.rtdt.ai/) im Rahmen eines Projekts Daten auf dem [<img src="/images/logo/EOSCA_logo.svg" alt="image" width="200" height="auto">](https://marketplace.eosc-portal.eu/) publiziert. 



