---
title: "Oliver Bischoff"
person-id: oliver-bischoff
firstname: "Oliver"
family: "Bischoff"
prenominals: Dipl. -Ing.
image: "/images/team/oliver-bischoff.png"
jobtitle: "Projektmanager"
email: oliver.bischoff@enviconnect.de
linkedinurl: "https://www.linkedin.com/in/bischoffoliver/"
promoted: true
weight: 2
---

Dipl. –Ing. der Luft- und Raumfahrttechnik mit langjähriger Erfahrung im Windenergiebereich. Mitarbeit an zahlreichen nationalen und internationalen F&E-Vorhaben und Richtlinien. Besondere Fachkenntnisse in den Bereichen Windmessung, Lidar und Windpotenzialabschätzung im On- und Offshore-Bereich.
