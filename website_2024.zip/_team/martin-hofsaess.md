---
title: "Martin Hofsäß"
person-id: martin-hofsaess
firstname: "Martin"
family: "Hofsaess"
prenominals: Dipl. -Ing.
email: martin.hofsaess@enviconnect.de
image: "/images/team/martin-hofsaess.png"
jobtitle: "Lidar Experte"
language: de
promoted: true
weight: 3
---

Dipl. –Ing. der Luft- und Raumfahrttechnik mit langjähriger Erfahrung im Windenergiebereich. Leitung und Beteiligung an nationalen Forschungsvorhaben; Besondere Fachkenntnisse in den Bereichen In-Situ- und Lidarmessungen und Datenanalyse.
