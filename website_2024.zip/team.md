---
title: Team
layout: teams
description: Team
permalink: "/team/"
intro_image_absolute: false
intro_image_hide_on_mobile: false
---

# Meet The Team

Consultancy Team

Between them, our consultancy team brings over 30 years of wind energy RD&D experience to bear on your problems. 

